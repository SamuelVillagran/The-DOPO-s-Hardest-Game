package domain;

public abstract class Entity extends Element {

	protected int speed;
	protected StateEntity state;
	
	public abstract void move(char direction);
	
	public String getNameClass() {
		return this.getClass().getSimpleName().toLowerCase();
	}
	
	public String getNameState() {
		return state.getClass().getSimpleName().toLowerCase();
	}
	
	public String getPathImage() {
		return "/"+getNameClass()+"/"+getNameState()+".png";		
	}
	
}
