package domain;

public class DimensionGame {
	
	public static final int MAXWORLDCOL = 30;
	public static final int MAXWORLDROW = 18;
	
	public static final int TILESIZE = 35;
	public static final int TILESIZEWIDTH = 38;
	public static final int TILESIZEHEIGHT = 35;
	
	public static final int SCREENWIDTH = TILESIZE*MAXWORLDCOL;
	public static final int SCREENHEIGHT = TILESIZE*MAXWORLDROW;

}
